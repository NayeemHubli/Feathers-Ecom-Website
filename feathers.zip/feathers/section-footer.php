<footer style="padding-top: 0px;">
            <div class="container">
                <div class="copyright-section">
                    <div class="row">
                        <div class="col-md-6">
                            &nbsp;
                        </div>
                        <div class="col-md-6">
                            <ul class="footer-nav">
                                <li class="facebook" id="facebook" onclick="PageShare(this.id)">
                                    <a  ><i class="fa fa-facebook"></i></a>
                                </li>

                                <li id="google" onclick="PageShare(this.id)">
                                    <a class="google"  ><i class="fa fa-google-plus"></i></a>
                                </li>
                                <li id="whatsapp"
                                    data-text="First time only in Belagavi / Buy Chicken online with ChickenWaala at lowest price  market, For more details call : 7406009888 ,visit now at *ChicenWaala* website" data-link="http://www.chickenwaala.com">
                                    <a class="google" ><i class="fa fa-phone-square"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
</footer>
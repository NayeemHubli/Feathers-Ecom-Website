<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="shortcut icon" type="images/icon2.png" href="images/icons/icon.png" />
<link rel="stylesheet" href="https://shahbaazchaviwale.github.io/js-css-library/cw-asset/css/bootstrap.min.css" type="text/css" media="screen">
    <link rel="stylesheet" href="https://shahbaazchaviwale.github.io/js-css-library/cw-css/font-awesome.min.css" type="text/css" media="screen">
    <link rel="stylesheet" type="text/css" href="https://shahbaazchaviwale.github.io/js-css-library/cw-css/style.css" media="screen">
    <link rel="stylesheet" type="text/css" href="https://shahbaazchaviwale.github.io/js-css-library/cw-css/responsive.css" media="screen">
    <link rel="stylesheet" type="text/css" href="https://shahbaazchaviwale.github.io/js-css-library/cw-css/animate.css" media="screen">
    <link rel="stylesheet" type="text/css" href="https://shahbaazchaviwale.github.io/js-css-library/cw-css/colors/red.css" title="red" media="screen" />
    <link rel="stylesheet" type="text/css" href="https://shahbaazchaviwale.github.io/js-css-library/toastr/toastr.min.css"/>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-5416663841915179",
    enable_page_level_ads: true
  });
</script>
    <!--[if IE 8]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
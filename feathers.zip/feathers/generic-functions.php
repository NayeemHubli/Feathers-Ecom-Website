<?php
/*Link Active*/
function make_decimal($data){
    return number_format($data);
}
?>
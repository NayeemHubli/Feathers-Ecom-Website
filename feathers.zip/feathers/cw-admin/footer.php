<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2021-2022 <a href="#">Feather.com</a></strong> All rights reserved.
</footer>

<!--tab icon-->
<link rel="shortcut icon" type="../images/icon2.png" href="../images/icon2.png" />
<!-- Tell the browser to be responsive to screen width -->
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<!-- Bootstrap 3.3.4 -->
<link href="https://shahbaazchaviwale.github.io/js-css-library/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<!-- Font Awesome Icons -->
<link href="https://shahbaazchaviwale.github.io/js-css-library/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<!-- Ionicons -->
<link href="https://shahbaazchaviwale.github.io/js-css-library/css/ionicons.min.css" rel="stylesheet" type="text/css" />
<!-- Theme style -->
<link href="https://shahbaazchaviwale.github.io/js-css-library/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
<!-- AdminLTE Skins. Choose a skin from the css/skins folder instead of downloading all of them to reduce the load. -->
<link href="../dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />

<link href="https://shahbaazchaviwale.github.io/js-css-library/css/style.css" rel="stylesheet" type="text/css" />
<!--Date picker-->
<link href="https://shahbaazchaviwale.github.io/js-css-library/date/bootstrap-datetimepicker.css" rel="stylesheet" type="text/css" />
<!-- DATA TABLES -->
<link href="https://shahbaazchaviwale.github.io/js-css-library/plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="../js/html5shiv.min.js"></script>
<script src="../js/respond.min.js"></script>
<![endif]-->

<style type="text/css">
    @media (min-width: 768px){
        #modal-dialog {
            width: 475px;
            margin: 50px auto;
        }
    }
        
</style>

<!--Toster-->
<link href=".https://shahbaazchaviwale.github.io/js-css-library/toastr/toastr.min.css" rel="stylesheet" type="text/css" />


<!-- jQuery 2.1.4 -->
<script src="https://shahbaazchaviwale.github.io/js-css-library/plugins/jQuery/jQuery-2.1.4.min.js" type="text/javascript"></script>
<!-- Bootstrap 3.3.2 JS -->
<script src="https://shahbaazchaviwale.github.io/js-css-library/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<!--Toster-->
<script src="https://shahbaazchaviwale.github.io/js-css-library/toastr/toastr.min.js" type="text/javascript"></script>
<!-- DATA TABES SCRIPT -->
<script src="https://shahbaazchaviwale.github.io/js-css-library/plugins/datatables/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://shahbaazchaviwale.github.io/js-css-library/plugins/datatables/dataTables.bootstrap.min.js" type="text/javascript"></script>
<script type="text/javascript">
    $(function () {
        $("#example1").DataTable();
    });
</script>

<!-- SlimScroll -->
<script src="https://shahbaazchaviwale.github.io/js-css-library/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
<!-- FastClick -->
<script src="https://shahbaazchaviwale.github.io/js-css-library/plugins/fastclick/fastclick.min.js" type="text/javascript"></script>
<!-- AdminLTE App -->
<script src="https://shahbaazchaviwale.github.io/js-css-library/dist/js/app.min.js" type="text/javascript"></script>

<!-- AdminLTE for demo purposes -->
<script src="https://shahbaazchaviwale.github.io/js-css-library/dist/js/demo.js" type="text/javascript"></script>
<script src="https://shahbaazchaviwale.github.io/js-css-library/js/response_ad.js" type="text/javascript"></script>
<!--date picker-->
<script src="https://shahbaazchaviwale.github.io/js-css-library/date/moment-with-locales.js" type="text/javascript"></script>
<script src="https://shahbaazchaviwale.github.io/js-css-library/date/bootstrap-datetimepicker.js" type="text/javascript"></script>


